#include <stdlib.h>
#include <stdio.h>
#include <dlfcn.h>
#include <pthread.h>
#include <cstdio>
#include <iostream>

#include "lib.h"

void *tfunc(void *pfunc) {
    printf("In thread. Running function...\n");
    void *(*func)() = (void *(*)())pfunc;
    
    SshTransport *t = (SshTransport *)func();
    if(t == nullptr) {
        printf("RIP, failed it...\n");
        return nullptr;
    }
    t->test();

    // wait so that whatever shenanigans we need to do can be completed
    // before the processes exits and dies...
    getchar();
    return nullptr;
}

void *tfunc2(void *pcls) {
    printf("In test 2 thread. Running function...\n");
    SshTransport *t = (SshTransport*)pcls;
    t->test();

    getchar();
    return nullptr;
}

int main(){
    void *handle = dlopen("./libtest.so", RTLD_NOW);
    if(!handle) {
        printf("Failed to load .so file: %s\n", dlerror());
        exit(1);
    }
    printf("Resolving function `test`...\n");

    // resolve the function
    void *(*testfunc)() = (void *(*)())dlsym(handle, "generate_class");
    if(!testfunc){
        printf("Failed to load function...\n");
        dlclose(handle);
        return 1;
    }


    printf("Loaded library. Trying `malloc`...\n");

    // resolve the malloc symbol
    pthread_t thread_id1, thread_id2;
    pthread_create(&thread_id1, NULL, tfunc, (void*)testfunc);
    pthread_join(thread_id1, NULL);
    
    SshTransport *t = (SshTransport *)testfunc();
    if(t == nullptr) {
        printf("RIP, failed it...\n");
    }
    pthread_create(&thread_id2, NULL, tfunc2, (void*)t);
    pthread_join(thread_id2, NULL);

    t->test();
    dlclose(handle);
    printf("Done\n");
    return 0;
}
