#include <stdlib.h>
#include <stdio.h>
#include "lib.h"


// initializes the instance data
SshTransport::SshTransport() {

}

// frees instance data and variables
SshTransport::~SshTransport() {
}

int SshTransport::test(){
        // try malloc
        void *heap_addr =  malloc(10);
        printf("Heap address: %p\n", heap_addr);
        if (heap_addr == NULL) {
            printf("Its null...\n");
            perror("");
            return 1;
        }
        return 0;
    
}



// API struct resolved at runtime, points to all the required functions
extern "C"{
    void *generate_class(){
        SshTransport *ptr = new SshTransport();
        return ptr;
    }
}