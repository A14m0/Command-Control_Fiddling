class SshTransport {
public:
    SshTransport();
    ~SshTransport();
    int test();
};