# Initial issue
We have a thread that calls a function which in turns calls `malloc`. This call to `malloc` fails, returning a `nullptr`. However, `malloc` succeeds on both the main thread and the child thread. 

Of note is that there are a few weird shenanigans going on in the code.
1. The class that runs in the child thread is spawned through a weird trampoline method
2. The library is dynamically loaded at runtime *by the main thread* (not the linker prior to `main` execution)

# What we have learned
1. `malloc` should work in a thread context. Additionally, it is also thread-safe, so no worries on that front
2. When someone says "all threads share a heap", they are instead referring to all *child* threads (main thread has its own, and `pthread_create` will `mmap` a region for all child threads spawned through it)
3. The issue does not appear when running thr program through GDB
    -> Could this mean its a loader issue?

Could this be an issue because the thing is loaded in the main thread first, but then is executed from a different context?

Likely not, as it worked here...